﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace RecipeAppWPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void IngredientFilterTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filterText = IngredientFilterTextBox.Text.ToLower();
            ApplyRecipeFilters(filterText);
        }

        private void FoodGroupComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (FoodGroupComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                string selectedFoodGroup = selectedItem.Content.ToString();
                ApplyRecipeFilters(foodGroup: selectedFoodGroup);
            }
        }

        private void MaxCaloriesSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double maxCalories = MaxCaloriesSlider.Value;
            ApplyRecipeFilters(maxCalories: maxCalories);
        }

        private void ApplyRecipeFilters(string ingredientName = null, string foodGroup = null, double? maxCalories = null)
        {
            RecipesListBox.Items.Filter = null;

            RecipesListBox.Items.Filter = recipe =>
            {
                Recipe r = (Recipe)recipe;

                if (!string.IsNullOrEmpty(ingredientName))
                {
                    bool hasIngredient = false;
                    foreach (Ingredient ingredient in r.Ingredients)
                    {
                        if (ingredient.Name.ToLower().Contains(ingredientName))
                        {
                            hasIngredient = true;
                            break;
                        }
                    }
                    if (!hasIngredient)
                        return false;
                }

                if (!string.IsNullOrEmpty(foodGroup) && foodGroup != "All Food Groups")
                {
                    bool hasFoodGroup = false;
                    foreach (Ingredient ingredient in r.Ingredients)
                    {
                        if (ingredient.FoodGroup.ToLower() == foodGroup.ToLower())
                        {
                            hasFoodGroup = true;
                            break;
                        }
                    }
                    if (!hasFoodGroup)
                        return false;
                }

                if (maxCalories.HasValue)
                {
                    int totalCalories = 0;
                    foreach (Ingredient ingredient in r.Ingredients)
                    {
                        totalCalories += ingredient.Calories;
                    }
                    if (totalCalories > maxCalories.Value)
                        return false;
                }

                return true;
            };
        }
    }
}

