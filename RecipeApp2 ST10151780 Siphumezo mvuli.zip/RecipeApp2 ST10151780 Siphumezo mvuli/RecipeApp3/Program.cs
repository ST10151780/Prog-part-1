﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    class Step
    {
        public string Description { get; set; }
    }

    class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe: " + Name);
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in Ingredients)
            {
                Console.WriteLine("- {0} {1} {2}", ingredient.Quantity, ingredient.Unit, ingredient.Name);
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, Steps[i].Description);
            }
        }

        public void ScaleRecipe(double factor)
        {
            foreach (Ingredient ingredient in Ingredients)
            {
                ingredient.Quantity *= factor;
            }
            DisplayRecipe();
        }

        public void ResetQuantities()
        {
            // TODO: Implement resetting quantities to original values
        }
    }

    class RecipeApp
    {
        private List<Recipe> recipes;

        public RecipeApp()
        {
            recipes = new List<Recipe>();
        }

        public void AddRecipe()
        {
            Recipe recipe = new Recipe();

            Console.WriteLine("Enter the name of the recipe:");
            recipe.Name = Console.ReadLine();

            Console.WriteLine("Enter the number of ingredients:");
            int numOfIngredients = int.Parse(Console.ReadLine());

            for (int i = 0; i < numOfIngredients; i++)
            {
                Ingredient ingredient = new Ingredient();

                Console.WriteLine("Enter the name of ingredient {0}:", i + 1);
                ingredient.Name = Console.ReadLine();

                Console.WriteLine("Enter the quantity of {0}:", ingredient.Name);
                ingredient.Quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter the unit of measurement for {0}:", ingredient.Name);
                ingredient.Unit = Console.ReadLine();

                Console.WriteLine("Enter the number of calories for {0}:", ingredient.Name);
                ingredient.Calories = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the food group for {0}:", ingredient.Name);
                ingredient.FoodGroup = Console.ReadLine();

                recipe.Ingredients.Add(ingredient);
            }

            Console.WriteLine("Enter the number of steps:");
            int numOfSteps = int.Parse(Console.ReadLine());

            for (int i = 0; i < numOfSteps; i++)
            {
                Step step = new Step();

                Console.WriteLine("Enter step description {0}:", i + 1);
                step.Description = Console.ReadLine();

                recipe.Steps.Add(step);
            }

            recipes.Add(recipe);
        }

        public void DisplayAllRecipes()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes available.");
                return;
            }

            Console.WriteLine("Recipes:");

            List<string> recipeNames = recipes.Select(r => r.Name).OrderBy(n => n).ToList();

            foreach (string recipeName in recipeNames)
            {
                Console.WriteLine(recipeName);
            }
        }

        public void DisplayRecipeDetails(string recipeName)
        {
            Recipe recipe = recipes.FirstOrDefault(r => r.Name == recipeName);

            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            recipe.DisplayRecipe();

            int totalCalories = recipe.Ingredients.Sum(i => i.Calories);
            Console.WriteLine("Total Calories: " + totalCalories);

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories!");
            }
        }

        public void Run()
        {
            while (true)
            {
                Console.WriteLine("=== Recipe App ===");
                Console.WriteLine("1. Add a Recipe");
                Console.WriteLine("2. Display All Recipes");
                Console.WriteLine("3. Display Recipe Details");
                Console.WriteLine("4. Exit");

                Console.Write("Enter your choice: ");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddRecipe();
                        break;
                    case 2:
                        DisplayAllRecipes();
                        break;
                    case 3:
                        Console.Write("Enter the name of the recipe: ");
                        string recipeName = Console.ReadLine();
                        DisplayRecipeDetails(recipeName);
                        break;
                    case 4:
                        Console.WriteLine("Exiting the application...");
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            RecipeApp recipeApp = new RecipeApp();
            recipeApp.Run();
        }
    }
}