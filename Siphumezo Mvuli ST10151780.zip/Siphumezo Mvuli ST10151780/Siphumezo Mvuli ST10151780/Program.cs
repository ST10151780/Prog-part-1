﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Siphumezo_Mvuli_ST10151780
{
    class Recipe
    {
        private int numOfIngredients;
        private string[] ingredientNames;
        private int[] Quantities;
        private string[] Units;
        private int Steps;
        private string[] stepDescriptions;

        // Constructor to set default values
        public Recipe()
        {
            numOfIngredients = 0;
            Steps = 0;
        }

        // Method to add ingredient details
        public void AddIngredient()
        {
            Console.WriteLine("Enter the number of ingredients:");
            numOfIngredients = Convert.ToInt32(Console.ReadLine());

            // Initialize arrays for ingredient details
            ingredientNames = new string[numOfIngredients];
            Quantities = new int[numOfIngredients];
            Units = new string[numOfIngredients];

            for (int i = 0; i < numOfIngredients; i++)
            {
                Console.WriteLine("Enter the name of ingredient {0}:", i + 1);
                ingredientNames[i] = Console.ReadLine();

                Console.WriteLine("Enter the quantity of ingredient {0}:", i + 1);
                Quantities[i] = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the unit of measurement of ingredient {0}:", i + 1);
                Units[i] = Console.ReadLine();
            }
        }

        // Method to add step details
        public void AddSteps()
        {
            Console.WriteLine("Enter the number of steps:");
            Steps = Convert.ToInt32(Console.ReadLine());

            // Initialize array for step descriptions
            stepDescriptions = new string[Steps];

            for (int i = 0; i < Steps; i++)
            {
                Console.WriteLine("Enter the description of step {0}:", i + 1);
                stepDescriptions[i] = Console.ReadLine();
            }
        }

        // Method to display recipe details
        public void DisplayRecipe()
        {
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < numOfIngredients; i++)
            {
                Console.WriteLine("{0} {1} of {2}", Quantities[i], Units[i], ingredientNames[i]);
            }

            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps; i++)
            {
                Console.WriteLine("{0}. {1}", i + 1, stepDescriptions[i]);
            }
        }

        // Method to scale ingredient quantities
        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i < numOfIngredients; i++)
            {
                Quantities[i] = (int)Math.Round(Quantities[i] * factor);
            }
        }

        // Method to reset ingredient quantities to original values
        public void ResetQuantities()
        {
           
        }

        // Method to clear all recipe data
        public void ClearRecipe()
        {
            numOfIngredients = 0;
            ingredientNames = null;
            Quantities = null;
            Units = null;
            Steps = 0;
            stepDescriptions = null;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Recipe recipe = new Recipe();

            while (true)
            {
                Console.WriteLine("\nEnter a command (add, scale, reset, clear, display, or exit):");
                string input = Console.ReadLine();

                if (input.ToLower() == "add")
                {
                    recipe.AddIngredient();
                    recipe.AddSteps();
                }
                else if (input.ToLower() == "scale")
                {
                    Console.WriteLine("Enter the scaling factor (0.5, 2, or 3):");
                    double factor = Convert.ToDouble(Console.ReadLine());

                    recipe.ScaleRecipe(factor);
                }
                else if (input.ToLower() == "reset")
                {
                    recipe.ResetQuantities();
                }
                else if (input.ToLower() == "clear")
                {
                    recipe.ClearRecipe();
                }
                else if (input.ToLower() == "display")
                {
                    recipe.DisplayRecipe();
                }
                else if (input.ToLower() == "exit")
                {
                    break;
                }
            }
        }
    }
}

